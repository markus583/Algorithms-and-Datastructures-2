from random import random


class MonteCarlo:

    def __init__(self, length, width, rectangles):
        """constructor

        Keyword arguments:
        :param length -- length of the enclosing rectangle
        :param width -- width of the enclosing rectangle
        :param rectangles -- array that contains the embedded rectangles
        """

    def area(self, num_of_shots):
        """Method to estimate the area of the enclosing rectangle that is not covered by the embedded rectangles

        Keyword arguments:
        :param num_of_shots -- Number of generated random points whose location (inside/outside) is analyzed
        :return float -- the area of the enclosing rectangle not covered.
        :raises ValueError if any of the parameters is None
        """

    def inside(self, x, y, rect):
        """Method to determine if a given point (x,y) is inside a given rectangle

        Keyword arguments:
        :param x,y -- coordinates of the point to check
        :param rect -- given rectangle
        :return bool
        :raises ValueError if any of the parameters is None
        """
